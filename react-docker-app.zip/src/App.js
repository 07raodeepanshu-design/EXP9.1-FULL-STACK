import React from "react";

function App() {
  return (
    <div className="App">
      <h1>🚀 React App Dockerized with Multi-Stage Build</h1>
      <p>Served via Nginx in production mode.</p>
    </div>
  );
}

export default App;
